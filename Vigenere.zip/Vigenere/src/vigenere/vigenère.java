/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vigenere;

public class vigenère {
    String Entrada, Salida, Clave;
    String Alfa = "abcdefghijklmnñopqrstuvwxzy% ";

    public vigenère(String Entrada, String Salida, String Clave) {
        this.Entrada = Entrada;
        this.Salida = Salida;
        this.Clave = Clave;
    }

    public vigenère() {
    }
    

    public String getEntrada() {
        return Entrada;
    }

    public void setEntrada(String Entrada) {
        this.Entrada = Entrada;
    }

    public String getSalida() {
        return Salida;
    }

    public void setSalida(String Salida) {
        this.Salida = Salida;
    }

    public String getClave() {
        return Clave;
    }

    public void setClave(String Clave) {
        this.Clave = Clave;
    }
    
    public String Encriptacion(){
        
        int [] t = new int [Entrada.length()];
        int [] pa = new int [Entrada.length()];
        int [] cri = new int [Entrada.length()];
        
        for(int i=0; i<t.length; i++){
            t[i] = Alfa.indexOf(Entrada.substring(i, i+1));
            pa[i] = Alfa.indexOf(Clave.substring(i%Clave.length(), (i%Clave.length())+1));
            cri[i] = (t[i]+pa[i]) % Alfa.length();
            Salida = Salida+Alfa.substring(cri[i], cri[i+1]);
        }
        return Salida;
    }
    
    public String Desencriptacion(){
        
        int [] t = new int [Entrada.length()];
        int [] pa = new int [Entrada.length()];
        int [] cri = new int [Entrada.length()];
        int n = 0;
        
        for(int i=0; i<t.length; i++){
            t[i] = Alfa.indexOf(Entrada.substring(i, i+1));
            pa[i] = Alfa.indexOf(Clave.substring(i%Clave.length(), (i%Clave.length())+1));
            cri[i] = (t[i]-pa[i]) % Alfa.length();
            if(n<0){
                n= Alfa.length()+n;
            }
            Salida = Salida+Alfa.substring(cri[i], cri[i+1]);
        }
        return Salida; 
    }
}
